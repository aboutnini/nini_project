
var 버튼들 = document.querySelectorAll('.tab-button');
var div들 = document.querySelectorAll('.tab-content');

// 버튼들[0].addEventListener('click',function(){
//     document.querySelector('.orange').classList.remove('orange');
//     document.querySelector('.show').classList.remove('show');
//     버튼들[0].classList.add('orange');
//     div들[0].classList.add('show');
// })

// 버튼들[1].addEventListener('click',function(){
//     document.querySelector('.orange').classList.remove('orange');
//     document.querySelector('.show').classList.remove('show');
//     버튼들[1].classList.add('orange');
//     div들[1].classList.add('show');
// })

// 버튼들[2].addEventListener('click',function(){
//     document.querySelector('.orange').classList.remove('orange');
//     document.querySelector('.show').classList.remove('show');
//     버튼들[2].classList.add('orange');
//     div들[2].classList.add('show');
// })


//for 문

for ( let i = 0; i < 3; i++ ) {
    버튼들[i].addEventListener('click',function(){
        document.querySelector('.orange').classList.remove('orange');
        document.querySelector('.show').classList.remove('show');
        버튼들[i].classList.add('orange');
        div들[i].classList.add('show');
    })
    console.log(i);

}
